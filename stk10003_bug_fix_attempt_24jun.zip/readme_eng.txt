[Introduction]
This mod is an attempt to fix some of the bugs in S.T.A.L.K.E.R.
version 1.0003 (only!). It tries to keep the original gameplay and
balance as much as possible with a two exceptions.

Below is the list of the fixed bugs. It lacks the more detailed
technical description for the reason of the defect. Please see the
Russion version for this.

1) The crash in Pripyat which happens when the player reaches the group
of Monolith stalkers on western side of the alley. Reason: the misprint
in the pri_smart_monolith_stalker2_guard_2_walk way point flags.

2) Another random crash in Pripyat. Reason: the error in the function
that checks if npc's community is accepted into the gulag.

3) The crash in Yantar. Yes, it was not actually fixed in 1.0003.
I think GSC forgot to include the fix in the released patch. Reason:
wrong level_vertex_id in the way point yan_st_stalker3_patrol_1_walk.

4) Impossibility to find and kill the Poker bandit. The fix also
enables the additional automatic quest to protect the Duty camp in
Dark valley. Reason: the missed info portion.

5) Lack of many quests in the Wild territory location. Reason:
misprints in multiple script and configuration files of the game.

6) Lack of the Sidorovich's automatic quest to destroy the bandit camp
at Auto park in Escape: Reason another misprint.

7) Lack of the Barman's quest to destroy the lair of snorks in Dark
Valley. Reason: snorks were not allowed in the location so the gulag
val_snork_lair_1 was always empty.

8) Possibility to fake the completion of many "defend camp" quests by
saving/loading the game or by going to different location. Partial fix
only. Reason: the state of the task was not correctly restored.

9) Occasional impossibility to complete some quests to destroy the
monster's lair if pseudodogs are involved. Reason: offline (invisible)
mutants were assigned in to the gulag.

10) Impossibility to complete the quest to protect the border near
the army warehouses from the monsters in a fair way. Reason: the error
in the function that calculates the gulag state.

11) Mercenaries never attack the stalkers in Army warehouses, zombied
stalkers never attack the neutral stalker's camp in Yantar. Reason:
wrong path names of the attack.

12) Poor set of goods in Barman's and Duty's stocks even after
completing the important quests. This was implemented by the authors
of the game in 1.0001+ but never worked due to an error.

13) Impossibility to complete the Lukash quest to destroy the Skull's
group in Army warehouses if there were game loads. Reason: kill counter
in the Skull group was not saved.

14) Occasional impossibility to complete the quest to destroy the
bloodsucker's lair in Army warehouses. Reason: another offline mutant
due to the error in function that checks npc community.

15) Two empty gulags in Pripyat populated with controllers. Reason:
the misprint in the accepted communities list.

16) An empty gulag in Escape with bloodsucker activated after the
Agroprom documents quest. Reason: similar misprints in the accepted
communities list.

17) 

18) The misprint in xr_effects.bar_territory_logic().

19) The defect in state_mgr.script. It was found and fixed by Red75.


And below are some additional changes:

20) Enabled the bandits on the guard towers in Dark valley. It is
necessary to start a new game to see this change.

21) Persistent treasure (stash) manager.
Important note! Older saves are compatible with this change. However,
new saves this this mod are _not_ compatible with the original game.

22) No weapon repair in dead bodies cheat.

23) Output the abort() message in the game console to get a bit more
description for the reason of the crash.


[Installation]
Copy gamedata into the folder of the game. Files in the
gamedata\config\text\rus folder can be safely deleted.

Do not install the db.script and se_monster.script if you are going
to start new game. They are required for the play from saves only.


[Partial installation]
Do not copy bind_stalker.script, se_stalker.script, xr_motivator.script
and treasure_manager.script if you do not need the change 21. However,
the fix 3 is not guaranteed in this case when playing from the game
save (new game is fine).

gamedata.opt is the version that fully fixes the problem 8. Very
experimental!

gamedata.debug is the version of the scripts with debug mark spots on
the map. Copy over the normal versions.


[Known problems]
TBD


[Disclaimer]
It is unlikely I will respond to any requests to rework these changes
and fixes, because it is a kind of "personal" mod. Therefore, feel free
to use the mod or its part (excepting the string_table_enc_weapons.xml)
at your will.
